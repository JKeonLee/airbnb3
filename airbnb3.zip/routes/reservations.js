var express = require('express'),
    Post = require('../models/Post'),
    User = require('../models/User');
var router = express.Router();

function needAuth(req, res, next) {
  if (req.isAuthenticated()) {
    next();
  } else {
    req.flash('danger', '로그인이 필요합니다.');
    res.redirect('/signin');
  }
}

function validateForm(form, options) {
  var title = form.title || "";
  var price = form.price || "";
  var room = form.rooms || "";
  var address = form.address || "";
  var toilet = form.toilets || "";
  title = title.trim();
  price = price.trim();

  if (!title) {
    return '제목을 입력해주세요.';
  }

  if (!address){
    return '주소를 입력해주세요.';
  }
  
  return null;
}

/* GET users listing. */
router.get('/', needAuth, function(req, res, next) {
  User.find({}, function(err, users) {
    if (err) {
      return next(err);
    }
  });
  Post.find({}, function(err, posts, users) {
    if (err) {
      return next(err);
    }
    res.render('reservations/index', {users: users, posts:posts});
    });
});

router.get('/new', needAuth, function(req, res, next) {
  User.find({}, function(err, users) {
    if (err) {
      return next(err);
    }
  });
  Post.find({}, function(err, posts) {
    if (err) {
      return next(err);
    }
    res.render('reservations/new', {posts:posts});
    });
});

module.exports = router;