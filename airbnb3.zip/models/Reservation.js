var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    ObjectId = Schema.ObjectId;

var schema = new Schema({
  rsv_title: {type: String, required: true},
  checkin: {type: String, required: true, trim: true},
  checkout:{type: String, required: true, trim: true},
  people:{type: Number, required: true},
  rsv_info: {type: String},
  status:{type: Number, required: true},
  createdAt: {type: Date, default: Date.now}
}, {
  toJSON: { virtuals: true},
  toObject: {virtuals: true}
});

var Reservation = mongoose.model('Reservation', schema);

module.exports = Reservation;